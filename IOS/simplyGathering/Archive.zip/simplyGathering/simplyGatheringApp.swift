//
//  simplyGatheringApp.swift
//  simplyGathering
//
//  Created by Student on 5/12/25.
//

import SwiftUI

@main
struct simplyGatheringApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
